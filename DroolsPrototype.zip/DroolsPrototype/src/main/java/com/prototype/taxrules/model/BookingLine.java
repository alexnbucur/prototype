package com.prototype.taxrules.model;

import java.math.BigDecimal;

public class BookingLine {
	
	private BigDecimal amount;
	
	private String type;
	
	private String paraFiscalType = "";

	public BookingLine(BigDecimal amount, String type) {
		super();
		this.amount = amount;
		this.type = type;
	}

	public BookingLine(String type) {
		super();
		this.type = type;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	@Override
	public String toString() {
		return "BookingLine [amount:" + amount + ", " + type  + paraFiscalTypeString() +"]";
	}

	public String getParaFiscalType() {
		return paraFiscalType;
	}

	public void setParaFiscalType(String paraFiscalType) {
		this.paraFiscalType = paraFiscalType;
	}
	
	public String paraFiscalTypeString() {
		String placeholder = "";
		if(paraFiscalType.isEmpty()) return "";
		else
			return ", "+ paraFiscalType;
	}
	
	
	

}
