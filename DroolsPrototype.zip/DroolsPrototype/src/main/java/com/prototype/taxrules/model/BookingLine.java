package com.prototype.taxrules.model;

import java.math.BigDecimal;

public class BookingLine {
	
	private BigDecimal amount;
	
	private String type;

	public BookingLine(BigDecimal amount, String type) {
		super();
		this.amount = amount;
		this.type = type;
	}

	public BookingLine(String type) {
		super();
		this.type = type;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	@Override
	public String toString() {
		return "BookingLine [" + amount + ", " + type + "]";
	}
	
	
	

}
