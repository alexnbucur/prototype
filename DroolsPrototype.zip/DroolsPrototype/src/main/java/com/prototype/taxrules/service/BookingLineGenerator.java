package com.prototype.taxrules.service;



import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.Set;

import com.prototype.taxrules.model.Booking;
import com.prototype.taxrules.model.BookingLine;

public class BookingLineGenerator {
	
	
	

	public BookingLineGenerator(String insuranceType, String insuranceSubType, String taxCountry, Date periodStart,
			BigDecimal amount) {
		super();
		this.insuranceType = insuranceType;
		this.insuranceSubType = insuranceSubType;
		this.taxCountry = taxCountry;
		this.periodStart = periodStart;
		this.amount = amount;
		this.booking = new Booking(amount);
	}

	private String insuranceType;
	
	private String insuranceSubType;
	
	private String taxCountry;
	
	private Date periodStart;
	
	private BigDecimal amount;
	
	private Booking booking;
	
	private BookingLine newBookingLine;
	
	public void createBookingLineOfType(String type) {
		this.newBookingLine = new BookingLine(type);
	}

	public String getInsuranceType() {
		return insuranceType;
	}

	public void setInsuranceType(String insuranceType) {
		this.insuranceType = insuranceType;
	}

	public String getInsuranceSubType() {
		return insuranceSubType;
	}

	public void setInsuranceSubType(String insuranceSubType) {
		this.insuranceSubType = insuranceSubType;
	}

	public String getTaxCountry() {
		return taxCountry;
	}

	public void setTaxCountry(String taxCountry) {
		this.taxCountry = taxCountry;
	}

	public Date getPeriodStart() {
		return periodStart;
	}

	public void setPeriodStart(Date periodStart) {
		this.periodStart = periodStart;
	}
	
	public void addPercentage(Double percenetage) {
		newBookingLine.setAmount(amount.multiply(new BigDecimal(percenetage)
				.divide(new BigDecimal(100)).setScale(2,RoundingMode.HALF_UP)));
		this.booking.getBookingLines().add(newBookingLine);
	}
	
	public void addAmount(Double amount) {
		newBookingLine.setAmount(new BigDecimal(amount).setScale(2,RoundingMode.HALF_UP));
		this.booking.getBookingLines().add(newBookingLine);
	}
	
	public void calculateAmount(Double number) {
		if (number != 0.0) {
			switch (this.newBookingLine.getType()) {

			case "IPT":
				System.out.println(
						"***** BookingLine of type IPT with " + number + "% is being added to the Booking ***** \n");
				addPercentage(number);
				break;
			case "Para_Fiscal":
				System.out.println("***** BookingLine of type Para Fiscal with amount " + number
						+ " is being added to the Booking ***** \n");
				addAmount(number);
				break;

			}
		}

	}

	public Booking getBooking() {
		return booking;
	}

	public void setBooking(Booking booking) {
		this.booking = booking;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	@Override
	public String toString() {
		return "BookingLineGenerator [" +insuranceType + ", " + insuranceSubType
				+ ", " + taxCountry + ", " + periodStart + ", " + amount + "]";
	}
	
	
	
	
}
