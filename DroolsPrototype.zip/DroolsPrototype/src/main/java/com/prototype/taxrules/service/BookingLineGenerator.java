package com.prototype.taxrules.service;



import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.logging.Logger;

import com.prototype.taxrules.model.Booking;
import com.prototype.taxrules.model.BookingLine;

import javassist.bytecode.stackmap.TypeData.ClassName;

public class BookingLineGenerator {
	
	private static final Logger LOGGER = Logger.getLogger( ClassName.class.getName() );
	

	public BookingLineGenerator(String insuranceType, String insuranceSubType, String taxCountry, Date periodStart,
			BigDecimal amount) {
		super();
		this.insuranceType = insuranceType;
		this.insuranceSubType = insuranceSubType;
		this.taxCountry = taxCountry;
		this.periodStart = periodStart;
		this.amount = amount;
		this.booking = new Booking(amount);
	}

	private String insuranceType;
	
	private String insuranceSubType;
	
	private String taxCountry;
	
	private Date periodStart;
	
	private BigDecimal amount;
	
	private Booking booking;
	
	private BookingLine newBookingLine;
	
	public void createBookingLineOfType(String type) {
		this.newBookingLine = new BookingLine(type);
	}

	public String getInsuranceType() {
		return insuranceType;
	}

	public void setInsuranceType(String insuranceType) {
		this.insuranceType = insuranceType;
	}

	public String getInsuranceSubType() {
		return insuranceSubType;
	}

	public void setInsuranceSubType(String insuranceSubType) {
		this.insuranceSubType = insuranceSubType;
	}

	public String getTaxCountry() {
		return taxCountry;
	}

	public void setTaxCountry(String taxCountry) {
		this.taxCountry = taxCountry;
	}

	public Date getPeriodStart() {
		return periodStart;
	}

	public void setPeriodStart(Date periodStart) {
		this.periodStart = periodStart;
	}
	
	public String getBookingDate() {
		DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");  
		return  dateFormat.format(periodStart);  
	}
	
	public void setParafiscalType(String pfType) {
		if(pfType!="") {
			newBookingLine.setParaFiscalType(pfType);
		}
	}
	
	public void addPercentage(Double percenetage) {
		newBookingLine.setAmount(amount.multiply(new BigDecimal(percenetage)
				.divide(new BigDecimal(100)).setScale(2,RoundingMode.HALF_UP)));
		this.booking.getBookingLines().add(newBookingLine);
	}
	
	public void addAmount(Double amount) {
		newBookingLine.setAmount(new BigDecimal(amount).setScale(2,RoundingMode.HALF_UP));
		this.booking.getBookingLines().add(newBookingLine);
	}
	
	@SuppressWarnings("restriction")
	public void calculateAmount(Double number) {
		if (number != 0.0) {
			switch (this.newBookingLine.getType()) {

			case "IPT":
				//LOGGER.info("BookingLine of type IPT with " + number + "% is being added to the Booking ");
				System.out.println("BookingLine of type IPT with " + number + "% is being added to the Booking ");
				addPercentage(number);
				break;
			case "PFP":
				//LOGGER.info("BookingLine of type Para Fiscal with " + number+ "% is being added to the Booking");
				System.out.println("BookingLine of type Para Fiscal with " + number+ "% is being added to the Booking");
				addPercentage(number);
				break;
			case "PFF":
				//LOGGER.info("BookingLine of type ParaFiscal with amount " + number + " is being added to the Booking" );
				System.out.println("BookingLine of type ParaFiscal with amount " + number + " is being added to the Booking" );
				addAmount(number);
				break;

			}
		}else {
			//LOGGER.info("BookingLine of type "+ this.newBookingLine.getType() +" is being skipped because the value is 0");
			System.out.println("BookingLine of type "+ this.newBookingLine.getType() +" is being skipped because the value is 0");
		}

	}

	public Booking getBooking() {
		return booking;
	}

	public void setBooking(Booking booking) {
		this.booking = booking;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	@Override
	public String toString() {
		return "BookingLineGenerator [" + insuranceType + ", " + insuranceSubType
				+ ", " + taxCountry + ", " + getBookingDate() + ", " + amount + "]";
	}
	
	

	
	
	
	
	
}
