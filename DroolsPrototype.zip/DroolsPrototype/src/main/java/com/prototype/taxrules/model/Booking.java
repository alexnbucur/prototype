package com.prototype.taxrules.model;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class Booking {
	
	private BigDecimal amount;
	
	private List<BookingLine> bookingLines = new ArrayList<>();

	public BigDecimal getAmount() {
		return amount;
	}

	public Booking() {
		super();
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public List<BookingLine> getBookingLines() {
		return bookingLines;
	}

	public void setBookingLines(List<BookingLine> bookingLines) {
		this.bookingLines = bookingLines;
	}

	public Booking(BigDecimal amount, List<BookingLine> bookingLines) {
		super();
		this.amount = amount;
		this.bookingLines = bookingLines;
	}

	

	public Booking(BigDecimal amount) {
		super();
		this.amount = amount;
	}

	@Override
	public String toString() {
		return "Booking [ premiumAmount:" + amount + ", " + bookingLines + "]";
	}
	
	
	

}
