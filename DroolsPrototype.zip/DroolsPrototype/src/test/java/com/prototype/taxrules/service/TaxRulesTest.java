package com.prototype.taxrules.service;

import static org.junit.Assert.assertEquals;

import java.math.BigDecimal;
import java.util.Date;
import java.util.logging.Logger;

import org.drools.core.event.DefaultAgendaEventListener;
import org.junit.Before;
import org.junit.Test;
import org.kie.api.event.rule.AfterMatchFiredEvent;
import org.kie.api.event.rule.MatchCreatedEvent;
import org.kie.api.event.rule.ObjectDeletedEvent;
import org.kie.api.event.rule.ObjectInsertedEvent;
import org.kie.api.event.rule.ObjectUpdatedEvent;
import org.kie.api.event.rule.RuleRuntimeEventListener;
import org.kie.api.io.Resource;
import org.kie.api.runtime.KieSession;
import org.kie.internal.io.ResourceFactory;

import com.baeldung.drools.config.DroolsBeanFactory;

import javassist.bytecode.stackmap.TypeData.ClassName;

@SuppressWarnings("restriction")
public class TaxRulesTest {
	
	private static final Logger LOGGER = Logger.getLogger( ClassName.class.getName() );
	
	private KieSession kSession;

    @Before
    public void setup() {
    //System.out.println(new DroolsBeanFactory().getDrlFromExcel("com/prototype/taxrules/TaxRules.xls"));
        Resource resource = ResourceFactory.newClassPathResource("com/prototype/taxrules/_TaxRules.xls", getClass());
        kSession = new DroolsBeanFactory().getKieSession(resource);
    }

    @Test
    public void test_Storage_BE() throws Exception {
    	
    	BookingLineGenerator bookingLineGenerator = new BookingLineGenerator("Cargo", "Storage", "BE", new Date(),new BigDecimal(2000));
    	
    	executeDrools(bookingLineGenerator);

        assertEquals(bookingLineGenerator.getBooking().getBookingLines().size(), 1);
    }
    
    @Test
    public void test_Transport_Domestic_FR() throws Exception {
    	
    	BookingLineGenerator bookingLineGenerator = new BookingLineGenerator("Cargo", "Transport-Domestic", "FR", new Date(),new BigDecimal(4000));
    	
    	executeDrools(bookingLineGenerator);

        assertEquals(bookingLineGenerator.getBooking().getBookingLines().size(), 3);
    }
    
    @Test
    public void test_Fire_DE() throws Exception {
    	
    	BookingLineGenerator bookingLineGenerator = new BookingLineGenerator("Cargo", "Fire", "DE", new Date(),new BigDecimal(500));
    	
    	executeDrools(bookingLineGenerator);

        assertEquals(bookingLineGenerator.getBooking().getBookingLines().size(), 2);
    }
    
    @Test
    public void test_Period_SE_shouldBeEmpty() throws Exception {
    	
    	BookingLineGenerator bookingLineGenerator = new BookingLineGenerator("Cargo", "Fire", "SE", new Date(),new BigDecimal(500));
    	
    	executeDrools(bookingLineGenerator);

        assertEquals(bookingLineGenerator.getBooking().getBookingLines().size(), 0);
    }
    
    @Test
    public void test_Period_SE_Should_have_IPT() throws Exception {
    	
    	BookingLineGenerator bookingLineGenerator = new BookingLineGenerator("Cargo", "Storage", "SE", new Date(1686348000000L),new BigDecimal(500));
    	
    	executeDrools(bookingLineGenerator);

        assertEquals(bookingLineGenerator.getBooking().getBookingLines().size(), 1);
    }
    
    

	private void executeDrools(BookingLineGenerator bookingLineGenerator) {
		System.out.println("----- START PROCESS ----- \n");
    	System.out.println(bookingLineGenerator.toString()+"\n");

    	attatchListeners(bookingLineGenerator);
        kSession.insert(bookingLineGenerator);
        
        System.out.println("----- RULES ARE BEING FIRED ----- \n");
        kSession.fireAllRules();
        
        kSession.dispose();
        System.out.println("----- KIE SESSION IS BEING CLOSED ----- \n");
        
        System.out.println("----- RESULT -----\n");
        System.out.println(bookingLineGenerator.getBooking().toString()+"\n");
        System.out.println("***********************************************************************\n");
	}

	private void attatchListeners(BookingLineGenerator bookingLineGenerator) {
		kSession.addEventListener(new DefaultAgendaEventListener() {
            
            
            public void matchCreated(MatchCreatedEvent  event) {
                super.matchCreated(event);
                //LOGGER.info("Rule "+ event.getMatch().getRule().getName() + " has been applied");
                System.out.println("Rule "+ event.getMatch().getRule().getName() + " has been applied");
            }
            public void afterMatchFired(AfterMatchFiredEvent event) {
                super.afterMatchFired(event);
                //LOGGER.info(bookingLineGenerator.getBooking().toString()); 
                System.out.println(bookingLineGenerator.getBooking().toString()+"\n"); 
            }
        });
    	kSession.addEventListener(new RuleRuntimeEventListener() {
            @Override
            public void objectInserted(ObjectInsertedEvent event) {
                //LOGGER.info("Request created :" + event.getObject().toString());
            }

			@Override
			public void objectDeleted(ObjectDeletedEvent arg0) {
				// TODO Auto-generated method stub
				
			}

			@Override
			public void objectUpdated(ObjectUpdatedEvent arg0) {
				// TODO Auto-generated method stub
				
			}

        });
	}

}
