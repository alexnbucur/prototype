package com.prototype.taxrules.service;

import static org.junit.Assert.assertEquals;

import java.math.BigDecimal;
import java.util.Date;

import org.junit.Before;
import org.junit.Test;
import org.kie.api.io.Resource;
import org.kie.api.runtime.KieSession;
import org.kie.internal.io.ResourceFactory;

import com.baeldung.drools.config.DroolsBeanFactory;

@SuppressWarnings("restriction")
public class TaxRulesTest {
	
	private KieSession kSession;

    @Before
    public void setup() {
    	//System.out.println(new DroolsBeanFactory().getDrlFromExcel("com/prototype/taxrules/TaxRules.xls"));
        Resource resource = ResourceFactory.newClassPathResource("com/prototype/taxrules/TaxRules.xls", getClass());
        kSession = new DroolsBeanFactory().getKieSession(resource);
    }

    @Test
    public void test_Storage_BE() throws Exception {
    	
    	BookingLineGenerator bookingLineGenerator = new BookingLineGenerator("Cargo", "Storage", "BE", new Date(),new BigDecimal(2000));
    	
    	executeDrools(bookingLineGenerator);

        assertEquals(bookingLineGenerator.getBooking().getBookingLines().size(), 1);
    }
    
    @Test
    public void test_Transport_Domestic_FR() throws Exception {
    	
    	BookingLineGenerator bookingLineGenerator = new BookingLineGenerator("Cargo", "Transport-Domestic", "FR", new Date(),new BigDecimal(4000));
    	
    	executeDrools(bookingLineGenerator);

        assertEquals(bookingLineGenerator.getBooking().getBookingLines().size(), 1);
    }
    
    @Test
    public void test_Fire_DE() throws Exception {
    	
    	BookingLineGenerator bookingLineGenerator = new BookingLineGenerator("Cargo", "Fire", "DE", new Date(),new BigDecimal(500));
    	executeDrools(bookingLineGenerator);

        assertEquals(bookingLineGenerator.getBooking().getBookingLines().size(), 2);
    }

	private void executeDrools(BookingLineGenerator bookingLineGenerator) {
		System.out.println("----- REQUEST HAS BEEN INSERTED TO THE KIE SESSION ----- \n");
    	System.out.println(bookingLineGenerator.toString()+"\n");
        kSession.insert(bookingLineGenerator);
        
        System.out.println("----- RULES ARE BEING FIRED ----- \n");
        kSession.fireAllRules();
        
        kSession.dispose();
        System.out.println("----- KIE SESSION IS BEING CLOSED ----- \n");
        
        System.out.println("----- RESULT -----\n");
        System.out.println(bookingLineGenerator.getBooking().toString());
	}

}
